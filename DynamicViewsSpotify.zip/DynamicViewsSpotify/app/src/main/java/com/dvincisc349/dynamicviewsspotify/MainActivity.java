package com.dvincisc349.dynamicviewsspotify;

import android.os.Bundle;
import android.util.LruCache;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private HolidaySongsAdapter adapter;
    private ArrayList<HolidaySongs> holidaySongsList;
    private LruCache<String, ArrayList<HolidaySongs>> cache;  // LRU Cache for storing the songs list

    private static final String JSON_URL = "https://nua.insufficient-light.com/data/holiday_songs_spotify.json"; // Replace with your JSON URL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        holidaySongsList = new ArrayList<>();

        // Initialize LRU Cache (Max size = 5MB)
        final int cacheSize = 1024 * 1024 * 5;  // 5MB
        cache = new LruCache<>(cacheSize);

        // Check if data exists in cache
        ArrayList<HolidaySongs> cachedData = cache.get("holiday_songs");
        if (cachedData != null) {
            holidaySongsList.addAll(cachedData);
            setupAdapter();
        } else {
            fetchDataFromJson();
        }
    }

    private void fetchDataFromJson() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                JSON_URL,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            holidaySongsList.clear(); // Clear old data

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                HolidaySongs song = new HolidaySongs(jsonObject);
                                holidaySongsList.add(song);
                            }

                            // Store in LRU Cache
                            cache.put("holiday_songs", new ArrayList<>(holidaySongsList));

                            // Setup adapter
                            setupAdapter();

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(MainActivity.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                });

        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void setupAdapter() {
        // Pass the RequestQueue when creating the adapter
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        adapter = new HolidaySongsAdapter(this, holidaySongsList, requestQueue);
        listView.setAdapter(adapter);
    }

}
